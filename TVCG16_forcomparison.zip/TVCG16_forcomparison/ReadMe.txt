The folder "Results_Lu_withInputs" consists of some results tested by our paper entitled "A Robust Scheme for Feature-preserving Mesh Denoising". Please free to use for your own comparisons with our method.

Note that noisy models with details or weak features (i.e., weak sharpness) could be challenging to denoise by employing the whole pipeline: details or weak features might be over-smoothed. So Devil, Angel, Julius and Rabbit are denoised by adopting only the first stage of our pipeline. Please mention it in your paper when you use the results for your comparions.

Also, please cite our work:

@ARTICLE{Lu2016, 
author={X. Lu and Z. Deng and W. Chen}, 
journal={IEEE Transactions on Visualization and Computer Graphics}, 
title={A Robust Scheme for Feature-Preserving Mesh Denoising}, 
year={2016}, 
volume={22}, 
number={3}, 
pages={1181-1194}, 
doi={10.1109/TVCG.2015.2500222}, 
ISSN={1077-2626}, 
month={March},}